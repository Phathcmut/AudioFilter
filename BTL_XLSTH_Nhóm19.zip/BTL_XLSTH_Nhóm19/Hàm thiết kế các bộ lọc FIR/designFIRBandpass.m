function h = designFIRBandpass(Fs, Fc1, Fc2, N) 

% Kiểm tra điều kiện chiều dài N là số lẻ 
if mod(N, 2) == 0 
error('Chiều dài N của bộ lọc phải là số lẻ.'); 
end 
% Chuẩn hóa tần số cắt 
fc1_norm = Fc1 / (Fs / 2); 
fc2_norm = Fc2 / (Fs / 2); 
% Tính toán đáp ứng xung lý tưởng h_d[n] 
n = 0:N-1; 
n_middle = (N-1) / 2; 
% Đáp ứng xung cho thông thấp với Fc2 
hd_lowpass2 = sin(2 * pi * fc2_norm * (n - n_middle)) ./ (pi * (n - n_middle)); 
hd_lowpass2(n_middle + 1) = 2 * fc2_norm; 
% Đáp ứng xung cho thông thấp với Fc1 
hd_lowpass1 = sin(2 * pi * fc1_norm * (n - n_middle)) ./ (pi * (n - n_middle)); 
hd_lowpass1(n_middle + 1) = 2 * fc1_norm; 
% Đáp ứng xung cho thông dải 
hd = hd_lowpass2 - hd_lowpass1; 
% Tạo hàm cửa sổ Hamming 
w = 0.54 - 0.46 * cos(2 * pi * n / (N - 1)); 
% Nhân đáp ứng xung lý tưởng với hàm cửa sổ 
h = hd .* w; 
% Hiển thị đáp ứng tần số của bộ lọc 
fvtool(h, 1); 
title('Đáp ứng tần số của bộ lọc FIR thông dải'); 
end
