function y = applyFIRFilter(h, x) 
% Thực hiện phép tích chập giữa tín hiệu và hệ số bộ lọc 
y_conv = conv(x, h, 'full'); % Tích chập đầy đủ 
% Để đầu ra có cùng độ dài với tín hiệu gốc: 
% Cắt bớt giá trị dư thừa ở phần đầu và phần cuối 
filter_delay = (length(h) - 1) / 2; % Độ trễ của bộ lọc 
y = y_conv(filter_delay + 1:end - filter_delay); % Loại bỏ biên dư thừa 
end
