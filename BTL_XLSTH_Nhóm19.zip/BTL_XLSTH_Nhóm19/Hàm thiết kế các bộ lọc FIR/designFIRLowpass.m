function h = designFIRLowpass(Fs, Fc, N)  
% Hàm thiết kế bộ lọc FIR thông thấp sử dụng cửa sổ Hamming  
%  
% Đầu vào:  
% Fs - Tần số lấy mẫu (Hz)  
% Fc - Tần số cắt (Hz)  
% N - Chiều dài của bộ lọc (số mẫu), phải là số lẻ  
%  
% Đầu ra:  
% h - Hệ số bộ lọc FIR thông thấp  
% Kiểm tra điều kiện chiều dài N là số lẻ  
if mod(N, 2) == 0  
error('Chiều dài N của bộ lọc phải là số lẻ.');  
end  
% Chuẩn hóa tần số cắt  
fc_norm = Fc / (Fs / 2);  
% Tính toán đáp ứng xung lý tưởng h_d[n]  
n = 0:N-1;  
n_middle = (N-1) / 2;  
hd = sin(2 * pi * fc_norm * (n - n_middle)) ./ (pi * (n - n_middle));  
hd(n_middle + 1) = 2 * fc_norm; % Xử lý tại vị trí 0 để tránh chia cho 0  
% Tạo hàm cửa sổ Hamming  
w = 0.54 - 0.46 * cos(2 * pi * n / (N - 1));  
% Nhân đáp ứng xung lý tưởng với hàm cửa sổ  
h = hd .* w;  
% Hiển thị đáp ứng tần số của bộ lọc  
fvtool(h, 1);  
title('Đáp ứng tần số của bộ lọc FIR thông thấp');  
end
