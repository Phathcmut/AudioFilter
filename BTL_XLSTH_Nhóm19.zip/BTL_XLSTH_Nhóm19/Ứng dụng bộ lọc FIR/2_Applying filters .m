% --- Thông số cơ bản --- 
Fs = 8000; % Tần số lấy mẫu (Hz) 
duration = 5; % Thời gian tín hiệu (giây) 
t = 0:1/Fs:duration-1/Fs; % Trục thời gian 
% --- Tạo tín hiệu âm thanh --- 
f1 = 500; % Tần số 500 Hz 
f2 = 900; % Tần số 900 Hz 
f3 = 1300; % Tần số 1300 Hz 
signal = 2*sin(2*pi*f1*t) + 5*sin(7*pi*f2*t) + 9*sin(2*pi*f3*t); 
% --- Thiết kế bộ lọc --- 
% Bộ lọc thông thấp 
Fc_lowpass = 600; % Tần số cắt 600 Hz 
N_lowpass = 51; % Độ dài bộ lọc 
h_lowpass = designFIRLowpass(Fs, Fc_lowpass, N_lowpass); 
% Bộ lọc thông cao 
Fc_highpass = 1000; % Tần số cắt 1000 Hz 
N_highpass = 51;  
h_highpass = designFIRHighpass(Fs, Fc_highpass, N_highpass); 
% Bộ lọc thông dải 
Fc1_bandpass = 600; % Tần số cắt thấp 
Fc2_bandpass = 1000; % Tần số cắt cao 
N_bandpass = 51; 
h_bandpass = designFIRBandpass(Fs, Fc1_bandpass, Fc2_bandpass, N_bandpass); 
% --- Áp dụng bộ lọc --- 
output_lowpass = applyFIRFilter(h_lowpass, signal); 
output_highpass = applyFIRFilter(h_highpass, signal); 
output_bandpass = applyFIRFilter(h_bandpass, signal); 
% --- Lưu tín hiệu sau khi lọc thành tệp âm thanh --- 
audiowrite('filtered_lowpass.wav', output_lowpass, Fs); 
audiowrite('filtered_highpass.wav', output_highpass, Fs); 
audiowrite('filtered_bandpass.wav', output_bandpass, Fs); 
% --- Xác định khoảng 2 chu kỳ để vẽ --- 
f_min = f1; % Tần số thấp nhất trong tín hiệu 
T_min = 1 / f_min; % Chu kỳ (giây) 
num_samples = round(2 * T_min * Fs * 5); % Số mẫu tương ứng với 2 chu kỳ 
% Lấy tín hiệu 2 chu kỳ 
t_plot = t(1:num_samples); 
signal_plot = signal(1:num_samples); 
output_lowpass_plot = output_lowpass(1:num_samples); 
output_highpass_plot = output_highpass(1:num_samples); 
output_bandpass_plot = output_bandpass(1:num_samples); 
% --- Vẽ tín hiệu --- 
figure; 
% Tín hiệu gốc 
subplot(4, 1, 1); 
plot(t_plot, signal_plot); 
title('Tín hiệu gốc (trước khi lọc)'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
% Tín hiệu sau khi lọc thông thấp 
subplot(4, 1, 2); 
plot(t_plot, output_lowpass_plot); 
title('Tín hiệu sau khi lọc FIR thông thấp'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
% Tín hiệu sau khi lọc thông cao 
subplot(4, 1, 3); 
plot(t_plot, output_highpass_plot); 
title('Tín hiệu sau khi lọc FIR thông cao'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
% Tín hiệu sau khi lọc thông dải 
subplot(4, 1, 4); 
plot(t_plot, output_bandpass_plot); 
title('Tín hiệu sau khi lọc FIR thông dải'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
