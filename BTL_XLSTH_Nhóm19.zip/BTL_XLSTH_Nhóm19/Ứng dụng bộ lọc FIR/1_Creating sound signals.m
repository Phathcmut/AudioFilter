% Thông số cơ bản 
Fs = 8000; % Tần số lấy mẫu (Hz) 
duration = 5; % Thời gian tín hiệu (giây) 
t = 0:1/Fs:duration-1/Fs; % Thời gian mẫu 
% Tạo tín hiệu với nhiều tần số 
f1 = 500; % Tần số 500 Hz 
f2 = 900; % Tần số 900 Hz 
f3 = 1300; % Tần số 1300 Hz 
signal = 2*sin(2*pi*f1*t) + 5*sin(7*pi*f2*t) + 9*sin(2*pi*f3*t); 
% Lưu tín hiệu vào tệp âm thanh 
audiowrite('multi_frequency_signal.wav', signal, Fs); 
% Vẽ tín hiệu để kiểm tra 
figure; 
plot(t(1:1000), signal(1:1000)); % Hiển thị 1000 mẫu đầu tiên 
title('Tín hiệu gồm nhiều tần số'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
[data, fs] = audioread("C:\Users\Phat\Documents\MATLAB\multi_frequency_signal.wav");% Đường dẫn
% Hiển thị tín hiệu trong khoảng 0.002 giây (tương ứng 2 chu kỳ của tần số 1000 Hz) 
figure; 
plot(t(1:round(0.002*Fs)), signal(1:round(0.002*Fs)));  
title('Tín hiệu gồm nhiều tần số (zoom 2 chu kỳ)'); 
xlabel('Thời gian (s)'); 
ylabel('Biên độ'); 
grid on; 
